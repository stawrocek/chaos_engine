#include "swab.h"

//https://github.com/eblot/newlib/blob/master/newlib/libc/string/swab.c
void swab(char* b1, char* b2, int length)
{
  const char *from = b1;
  char *to = b2;
  ssize_t ptr;
  for (ptr = 1; ptr < length; ptr += 2)
    {
      char p = from[ptr];
      char q = from[ptr-1];
      to[ptr-1] = p;
      to[ptr  ] = q;
    }
  if (ptr == length) /* I.e., if length is odd, */
    to[ptr-1] = 0;   /* then pad with a NUL. */
}