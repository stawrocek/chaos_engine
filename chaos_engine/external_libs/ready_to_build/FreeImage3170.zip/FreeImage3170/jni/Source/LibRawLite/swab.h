#ifndef SWAB_H
#define SWAB_H

#include <sys/types.h>

//https://github.com/eblot/newlib/blob/master/newlib/libc/string/swab.c
void swab(char* b1, char* b2, int length);

#endif
